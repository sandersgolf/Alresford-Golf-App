const CACHE = "alresford-tourpro-v14";
const ASSETS = ["./","./index.html","./manifest.json","./sw.js","./icon-192.png","./icon-256.png","./icon-512.png","./apple-touch-icon.png"];
self.addEventListener("install", e => e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener("activate", e => e.waitUntil(caches.keys().then(keys=>Promise.all(keys.map(k=>k!==CACHE?caches.delete(k):null))).then(()=>self.clients.claim())));
self.addEventListener("fetch", e => e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
