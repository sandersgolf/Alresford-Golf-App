ULTIMATE v14: App-store-level polish (iOS meta, ripple, glass UI, auto-hide minibar, pop animations, extra icons). Includes White+Yellow yardages.
